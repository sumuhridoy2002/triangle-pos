<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Quotation\\Providers\\QuotationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Quotation\\Providers\\QuotationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);