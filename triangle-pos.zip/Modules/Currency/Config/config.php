<?php

return [
    'name' => 'Currency'
];
