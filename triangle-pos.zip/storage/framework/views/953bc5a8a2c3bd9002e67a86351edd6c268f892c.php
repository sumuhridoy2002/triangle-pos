<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.4.0/perfect-scrollbar.js"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.server-side.js')); ?>"></script>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('third_party_scripts'); ?>

<?php echo \Livewire\Livewire::scripts(); ?>


<?php echo $__env->yieldPushContent('page_scripts'); ?>
<?php /**PATH E:\triangle-pos\resources\views/includes/main-js.blade.php ENDPATH**/ ?>