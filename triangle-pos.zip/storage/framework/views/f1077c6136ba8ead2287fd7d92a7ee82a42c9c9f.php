<!-- Dropezone CSS -->
<link rel="stylesheet" href="<?php echo e(asset('css/dropzone.css')); ?>">
<!-- CoreUI CSS -->
<link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>" crossorigin="anonymous">
<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

<?php echo $__env->yieldContent('third_party_stylesheets'); ?>

<?php echo \Livewire\Livewire::styles(); ?>


<?php echo $__env->yieldPushContent('page_css'); ?>

<style>
    div.dataTables_wrapper div.dataTables_length select {
        width: 65px;
        display: inline-block;
    }
</style>
<?php /**PATH E:\triangle-pos\resources\views/includes/main-css.blade.php ENDPATH**/ ?>